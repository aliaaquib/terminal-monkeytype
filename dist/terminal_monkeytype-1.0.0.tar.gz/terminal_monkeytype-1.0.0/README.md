# 🐵 Terminal Monkeytype

A beautiful, minimal, cross-platform **terminal-based typing test** inspired by [Monkeytype](https://monkeytype.com)
Test your typing speed, accuracy, and challenge yourself in **words mode** or **time mode** — all directly from your terminal!


## ⚡ Features

- **Words Mode**: Type a specific number of words (25, 50, 100)  
- **Time Mode**: Test your typing for a fixed time (15s, 30s, 60s, 120s)  
- **Real-time stats**: Displays WPM, accuracy, elapsed time, and mistakes while typing 
- **Vertical & horizontal scrolling**: Always see the current line of text, even if the text wraps  
- **Visually pleasing UI**:
  - Title centered at top
  - Typing test vertically centered
  - Stats below typing text
  - Footer with options: `[R] Restart`, `[M] Menu`, `[Q] Quit`, `[G] Github`
- **Leaderboard**: Stores recent results to track progress 

## 🎯 Installation

1. Clone this repository:

```bash
git clone https://github.com/imaaquibali/terminal-monkeytype.git
cd terminal-monkeytype 
```
2.	Install dependencies:
```bash
pip3 install prompt_toolkit rich
```
2.	Start typing:
```bash
python3 terminal-monkeytype.py
```

## 🏃 Usage

- **Choose mode**: Words or Time
- In Words mode select number of words
- In Time mode select duration
- Start typing and watch your stats update in real time
- After the test, view your results and recent leaderboard
- **Options after test**:
	•	[R] Retry
	•	[M] Menu
	•	[Q] Quit
	•	[G] Open GitHub

## 📂 Files
- terminal_monkeytype.py — Main application script
- leaderboard.json — Stores recent results (auto-generated)

## 🎨 UI Preview
┌──────────────────────────────────────────────┐
│           Terminal Monkeytype     Github [G] │
├──────────────────────────────────────────────┤
│                                              │
│  This is the typing test text shown here.    │
│  Current line is always centered vertically  │
│  Correct characters turn green, mistakes red │
│                                              │
├──────────────────────────────────────────────┤
│ ⏱ 12.3s   |   ⚡ 65.2 WPM   |   🎯 98%        |  
| Mistakes: 2                                  │
└──────────────────────────────────────────────┘
R[Restart]   M[Menu]   Q[Quit]   G[Github]

## 🛠 Built With
- Python 3.13+
- prompt_toolkit — for interactive terminal UI
- rich — for beautiful text, tables, and panels

## 🔗 License
This project is open-source. Feel free to fork, modify, and contribute!

## 🌟 Acknowledgements
Inspired by Monkeytype and terminal-based typing apps

## 🚀 Contribution
	1.	Fork the repo
	2.	Create your branch: git checkout -b feature-name
	3.	Commit your changes: git commit -m "Add feature"
	4.	Push to the branch: git push origin feature-name
	5.	Open a pull request

## 💻 Author
Aaquib Ali 